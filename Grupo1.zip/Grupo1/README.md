Autor: Fabrício Ferreira.

Sobre o Programa: 

Neste programa temos uma classe abstrata que será a base dos modelos de simulação de custos do programa.

A interface conta com os principais contratos sendo eles:

Custo de instalação (CustoInstalacao).
Manutenção (Manutencao).
Estimativa de Custos Iniciais: (CustoEstimado).
Economia de energia regional: (Economia).